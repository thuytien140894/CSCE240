/****************************************************************
 * Rather generic header file.
 *
 * Author/copyright:  Duncan Buell
 * Submitted by: Tien Ho
 * Date: 17 February 2015
 *
**/

#ifndef MAIN_H
#define MAIN_H

#include <iostream>
using namespace std;

#include "../../Utilities/Utils.h"
#include "../../Utilities/Scanner.h"

#include "DoTheWork.h"

class Main
{
public:
    int main();
    virtual ~Main();

private:

};

#endif // MAIN_H
