#include <iostream>
using namespace std;

/****************************************************************
 * Main program for Homework 1.
 *
 * Author/copyright:  Zachary Zyzzyvas. All rights reserved.
 * Date: 12 January 2015
 *
**/

int main(int argc, char *argv[])
{
  cout << "Hello, world." << endl;
  cout << "My name is Zachary Zyzzyvas." << endl;

  return 0;
}
