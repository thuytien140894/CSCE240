#include <iostream>
using namespace std;

/****************************************************************
 * Main program for Homework 1.
 *
 * Author/copyright:  Tien Ho. All rights reserved.
 * Date: 20 January 2015
 *
**/

int main(int argc, char *argv[])
{
  cout << "Hello, world." << endl;
  cout << "My name is Tien Ho." << endl;

  return 0;
}
